class Adder:
    
    def add(self,x,y):
        return x + y
        