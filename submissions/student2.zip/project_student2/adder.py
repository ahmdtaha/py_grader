class Adder:
    
    def add(self,x,y):
        return abs(x) + abs(y)
        